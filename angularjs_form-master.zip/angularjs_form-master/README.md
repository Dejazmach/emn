# AngularJS form example

This repository contains a dummy contact form powered by AngularJS.

See it in action at http://juampy72.github.io/angularjs_form

There is a step by step tutorial on this form at [the Lullabot Blog](https://www.lullabot.com/blog/article/processing-forms-angularjs).

## Installation

Simply clone this repository on a directory accessible from your local web server.
Then, open index.html from a web browser.
